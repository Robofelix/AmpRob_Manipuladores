function [P, Q]=generate_smooth_path(P1, P2, P3, tau, T, t)
    % Function that calculates the transformation (P - position, and Q - orientation) from P1 to P3 smoothing in P2 with Taylor method (quaternions)

    if (t<-T || t>T)
        % Out of allowed range
        disp('Parameter t out of range');
    else

        if (t<=-tau) % First segment (lineal)
            [P,Q]=qpinter(P1,P2,(t+T)/T);
        elseif (t>=tau) % Third segment (lineal)
            [P,Q]=qpinter(P2,P3,t/T);
        else % Second segment (smoothing)
            % Position interpolation
            P=P2(1:3,4)-(((tau-t)^2)/(4*tau*T))*(P2(1:3,4)-P1(1:3,4))+(((tau+t)^2)/(4*tau*T))*(P3(1:3,4)-P2(1:3,4));

            % Orientation interpolation
            q1=tr2q(P1(1:3,1:3));
            q2=tr2q(P2(1:3,1:3));
            q3=tr2q(P3(1:3,1:3));
            q12=qqmul(qinv(q1),q2);
            q23=qqmul(qinv(q2),q3);
            theta12=2*acos(q12(1));
            theta23=2*acos(q23(1));
            n12=q12(2:4)/sin(theta12/2);
            n23=q23(2:4)/sin(theta23/2);
            thetak1=((-(tau-t)^2)/(4*tau*T))*theta12;
            thetak2=(((tau+t)^2)/(4*tau*T))*theta23;
            qk1=[cos(thetak1/2),n12*sin(thetak1/2)];
            qk2=[cos(thetak2/2),n23*sin(thetak2/2)];
            Q=qqmul(q2,qqmul(qk1,qk2));
        end

    end
end