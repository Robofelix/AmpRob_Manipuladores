function [pr,qr]=qpinter(Pa,Pb,lambda)
    
    
    % Interpolate the position
    pr = Pa(1:3,4) + lambda*(Pb(1:3,4) - Pa(1:3,4));

    % Interpolate the orientation 
    qa=tr2q(Pa(1:3,1:3));
    qb=tr2q(Pb(1:3,1:3));
    qc=qqmul(qinv(qa),qb);
    theta=2*acos(qc(1));
    n=qc(2:4)/sin(theta/2);
    theta_lambda=lambda*theta;
    w_lambda=cos(theta_lambda/2);
    v_lambda=n*sin(theta_lambda/2);
    qrot =  [w_lambda v_lambda];
    qr=qqmul(qa,qrot);
end